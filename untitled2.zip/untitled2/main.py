__author__ = 'miguelolivares'

from notas import Seno
from archivar import Archivo
from Audiosystem import Audio


def main():

        print ("Generador de Onda Sinusoidal")
        Frecuenciadesampleo = 44100.0
        MaxBits = 16
        Buffer = 1024

        print ("Ingrese su opcion: ")
        Level = input("Ingrese el valor pico de la senal en dBfs: ")
        Nombre = raw_input("Ingrese el nombre del archivo a generar: ")

        onda = Seno(Frecuenciadesampleo, MaxBits)

        datos = onda.generar()
        datosAjustados = onda.leveladjust(datos,MaxBits,Level)
        archivo = Archivo(Frecuenciadesampleo, MaxBits, Nombre)
        archivo.archivar(datosAjustados)

        Seleccion = raw_input("Desea reproducir el audio generado(si/no): ")

        if Seleccion == "si":
            audio = Audio(Buffer)
            Datos = audio.abrir(Nombre)
            audio.inicio(Datos[0],Datos[1],Datos[2])
            audio.reproducir(Datos[3])
            audio.cerrar()


if __name__ == "__main__":
    main()
